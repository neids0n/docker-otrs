Please see [the installation instructions](https://otrscommunityedition.com/doc/manual/admin/6.0/en/html/installation.html)
in the online documentation.
